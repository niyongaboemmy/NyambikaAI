import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Package, Truck, CheckCircle, Clock, Eye } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

interface Order {
  id: string;
  items: any[];
  total: number;
  status: 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled';
  createdAt: string;
  shipping: any;
  paymentMethod: string;
}

const statusIcons = {
  pending: Clock,
  confirmed: CheckCircle,
  shipped: Truck,
  delivered: Package,
  cancelled: Package
};

const statusColors = {
  pending: 'bg-yellow-500',
  confirmed: 'bg-blue-500',
  shipped: 'bg-purple-500',
  delivered: 'bg-green-500',
  cancelled: 'bg-red-500'
};

export default function Orders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const { user } = useAuth();

  useEffect(() => {
    // Load orders from localStorage (in real app, this would be from API)
    const storedOrders = JSON.parse(localStorage.getItem('nyambika_orders') || '[]');
    setOrders(storedOrders);
  }, []);

  const getStatusText = (status: string) => {
    const statusMap = {
      pending: 'Pending',
      confirmed: 'Confirmed',
      shipped: 'Shipped',
      delivered: 'Delivered',
      cancelled: 'Cancelled'
    };
    return statusMap[status as keyof typeof statusMap] || status;
  };

  if (!user) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
        <p className="text-gray-600">Please log in to view your orders.</p>
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <Package className="mx-auto h-24 w-24 text-gray-400 mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-2">No orders yet</h1>
          <p className="text-gray-600 mb-8">Start shopping to see your orders here</p>
          <Button asChild>
            <a href="/products">Start Shopping</a>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Your Orders</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Orders List */}
        <div className="lg:col-span-2 space-y-4">
          {orders.map((order) => {
            const StatusIcon = statusIcons[order.status];
            return (
              <Card key={order.id} className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => setSelectedOrder(order)}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <p className="font-semibold text-lg">Order #{order.id}</p>
                      <p className="text-sm text-gray-600">
                        {new Date(order.createdAt).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className={statusColors[order.status]}>
                        <StatusIcon className="w-3 h-3 mr-1" />
                        {getStatusText(order.status)}
                      </Badge>
                      <Button variant="ghost" size="sm">
                        <Eye className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <div className="flex -space-x-2">
                      {order.items.slice(0, 3).map((item, index) => (
                        <img
                          key={index}
                          src={item.image}
                          alt={item.name}
                          className="w-10 h-10 rounded-full border-2 border-white object-cover"
                        />
                      ))}
                      {order.items.length > 3 && (
                        <div className="w-10 h-10 rounded-full border-2 border-white bg-gray-200 flex items-center justify-center text-xs font-medium">
                          +{order.items.length - 3}
                        </div>
                      )}
                    </div>
                    <div>
                      <p className="font-medium">{order.items.length} item{order.items.length > 1 ? 's' : ''}</p>
                      <p className="text-xl font-bold text-indigo-600">
                        {order.total.toLocaleString()} RWF
                      </p>
                    </div>
                  </div>

                  {/* Order Progress */}
                  <div className="mt-4 flex items-center space-x-2">
                    <div className={`h-2 flex-1 rounded ${order.status === 'pending' ? 'bg-yellow-200' : 'bg-green-200'}`}>
                      <div 
                        className={`h-full rounded ${
                          order.status === 'pending' ? 'bg-yellow-500 w-1/4' :
                          order.status === 'confirmed' ? 'bg-blue-500 w-2/4' :
                          order.status === 'shipped' ? 'bg-purple-500 w-3/4' :
                          order.status === 'delivered' ? 'bg-green-500 w-full' :
                          'bg-red-500 w-full'
                        }`}
                      ></div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Order Details */}
        <div className="lg:col-span-1">
          {selectedOrder ? (
            <Card className="sticky top-8">
              <CardHeader>
                <CardTitle>Order Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="font-semibold">Order #{selectedOrder.id}</p>
                  <p className="text-sm text-gray-600">
                    Placed on {new Date(selectedOrder.createdAt).toLocaleDateString()}
                  </p>
                </div>

                <Separator />

                {/* Items */}
                <div className="space-y-3">
                  <p className="font-medium">Items</p>
                  {selectedOrder.items.map((item, index) => (
                    <div key={index} className="flex space-x-3">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-12 h-12 rounded object-cover"
                      />
                      <div className="flex-1">
                        <p className="font-medium text-sm">{item.name}</p>
                        <p className="text-xs text-gray-600">
                          {item.size} • {item.color} • Qty: {item.quantity}
                        </p>
                        <p className="text-sm font-medium">
                          {(item.price * item.quantity).toLocaleString()} RWF
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                <Separator />

                {/* Shipping */}
                <div>
                  <p className="font-medium mb-2">Shipping Address</p>
                  <div className="text-sm text-gray-600">
                    <p>{selectedOrder.shipping.fullName}</p>
                    <p>{selectedOrder.shipping.address}</p>
                    <p>{selectedOrder.shipping.city}, {selectedOrder.shipping.district}</p>
                    <p>{selectedOrder.shipping.phone}</p>
                  </div>
                </div>

                <Separator />

                {/* Total */}
                <div className="flex justify-between text-lg font-bold">
                  <span>Total</span>
                  <span>{selectedOrder.total.toLocaleString()} RWF</span>
                </div>

                <Button className="w-full" variant="outline">
                  Track Order
                </Button>
              </CardContent>
            </Card>
          ) : (
            <Card className="sticky top-8">
              <CardContent className="p-8 text-center">
                <Package className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <p className="text-gray-600">Select an order to view details</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}