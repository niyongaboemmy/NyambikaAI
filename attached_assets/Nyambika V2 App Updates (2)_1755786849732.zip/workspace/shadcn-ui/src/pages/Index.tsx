import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Camera, Sparkles, Users, Shield } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

// Mock featured products
const featuredProducts = [
  {
    id: '1',
    name: 'Traditional Rwandan Dress',
    price: 45000,
    image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=300',
    category: 'Traditional'
  },
  {
    id: '2',
    name: 'Modern African Print Top',
    price: 25000,
    image: 'https://images.unsplash.com/photo-1560243563-062bfc001d68?w=300',
    category: 'Casual'
  },
  {
    id: '3',
    name: 'Elegant Evening Gown',
    price: 75000,
    image: '/images/EveningGown.jpg',
    category: 'Formal'
  },
  {
    id: '4',
    name: 'Casual Summer Outfit',
    price: 35000,
    image: 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=300',
    category: 'Summer'
  }
];

export default function Index() {
  const { t } = useLanguage();

  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center space-y-8">
            <h1 className="text-4xl md:text-6xl font-bold">
              {t('welcome')}
            </h1>
            <p className="text-xl md:text-2xl text-indigo-100 max-w-3xl mx-auto">
              AI-powered fashion platform for Rwanda's clothing sector. Try on clothes virtually and find your perfect size.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-white text-indigo-600 hover:bg-gray-100">
                <Link to="/products">Shop Now</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-indigo-600">
                <Link to="/virtual-tryon">
                  <Camera className="w-5 h-5 mr-2" />
                  Try Virtual Fitting
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose Nyambika?</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Experience the future of fashion shopping with our AI-powered platform designed for Rwanda's fashion industry.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mx-auto">
                <Camera className="w-6 h-6 text-indigo-600" />
              </div>
              <CardTitle>Virtual Try-On</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                See how clothes look on you before buying with our advanced AI technology.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto">
                <Sparkles className="w-6 h-6 text-purple-600" />
              </div>
              <CardTitle>Size Recommendation</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Get personalized size suggestions based on your measurements and body type.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto">
                <Users className="w-6 h-6 text-green-600" />
              </div>
              <CardTitle>Local Sellers</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Support local fashion businesses, cooperatives, and individual designers.
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mx-auto">
                <Shield className="w-6 h-6 text-orange-600" />
              </div>
              <CardTitle>Secure Payments</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Pay safely with mobile money (MTN, Airtel) or international cards.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Featured Products Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900">Featured Products</h2>
          <Button asChild variant="outline">
            <Link to="/products">View All</Link>
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <Card key={product.id} className="group hover:shadow-lg transition-shadow">
              <div className="aspect-square overflow-hidden rounded-t-lg">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <CardContent className="p-4">
                <Badge variant="secondary" className="mb-2">
                  {product.category}
                </Badge>
                <h3 className="font-semibold text-lg mb-2">{product.name}</h3>
                <div className="flex items-center justify-between">
                  <span className="text-xl font-bold text-indigo-600">
                    {product.price.toLocaleString()} RWF
                  </span>
                  <Button asChild size="sm">
                    <Link to={`/products/${product.id}`}>View</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-indigo-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Transform Your Fashion Experience?</h2>
          <p className="text-xl text-indigo-100 mb-8 max-w-2xl mx-auto">
            Join thousands of satisfied customers who trust Nyambika for their fashion needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-white text-indigo-600 hover:bg-gray-100">
              <Link to="/register">Get Started</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-indigo-600">
              <Link to="/virtual-tryon">Try Virtual Fitting</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}