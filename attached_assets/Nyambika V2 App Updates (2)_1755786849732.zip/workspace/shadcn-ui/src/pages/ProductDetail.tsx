import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Heart, Share2, ShoppingCart, Camera, Ruler, ArrowLeft } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { toast } from 'sonner';

// Mock product data - in real app this would come from API
const mockProduct = {
  id: '1',
  name: 'Traditional Rwandan Dress',
  price: 45000,
  originalPrice: 50000,
  images: [
    'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=600',
    'https://images.unsplash.com/photo-1560243563-062bfc001d68?w=600',
    '/images/TraditionalClothing.jpg'
  ],
  category: 'Traditional',
  sizes: ['XS', 'S', 'M', 'L', 'XL'],
  colors: ['Red', 'Blue', 'Green'],
  rating: 4.8,
  reviewCount: 124,
  seller: {
    name: 'Kigali Fashion House',
    id: 'seller1',
    rating: 4.9,
    totalProducts: 45
  },
  inStock: true,
  isNew: false,
  onSale: true,
  description: 'Beautiful traditional Rwandan dress made with authentic African fabric. Perfect for special occasions, cultural events, and celebrations. Handcrafted by skilled artisans in Rwanda.',
  features: [
    'Authentic African fabric',
    'Handcrafted design',
    'Traditional patterns',
    'Comfortable fit',
    'Machine washable'
  ],
  specifications: {
    'Material': '100% Cotton',
    'Origin': 'Rwanda',
    'Care': 'Machine wash cold',
    'Fit': 'Regular fit',
    'Length': 'Midi length'
  }
};

export default function ProductDetail() {
  const { id } = useParams();
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const { addItem } = useCart();
  const { t } = useLanguage();

  const handleAddToCart = () => {
    if (!selectedSize || !selectedColor) {
      toast.error('Please select size and color');
      return;
    }

    addItem({
      id: `${mockProduct.id}-${selectedSize}-${selectedColor}`,
      productId: mockProduct.id,
      name: mockProduct.name,
      price: mockProduct.price,
      image: mockProduct.images[0],
      size: selectedSize,
      color: selectedColor,
      sellerId: mockProduct.seller.id
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Breadcrumb */}
      <div className="flex items-center space-x-2 mb-8">
        <Button variant="ghost" size="sm" asChild>
          <Link to="/products">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Products
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Product Images */}
        <div className="space-y-4">
          <div className="aspect-square overflow-hidden rounded-lg bg-gray-100">
            <img
              src={mockProduct.images[selectedImage]}
              alt={mockProduct.name}
              className="w-full h-full object-cover"
            />
          </div>
          
          {/* Thumbnail Images */}
          <div className="flex space-x-4">
            {mockProduct.images.map((image, index) => (
              <button
                key={index}
                onClick={() => setSelectedImage(index)}
                className={`w-20 h-20 rounded-lg overflow-hidden border-2 ${
                  selectedImage === index ? 'border-indigo-600' : 'border-gray-200'
                }`}
              >
                <img src={image} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-4">
            <Button variant="outline" className="flex-1">
              <Camera className="w-4 h-4 mr-2" />
              Virtual Try-On
            </Button>
            <Button variant="outline" className="flex-1">
              <Ruler className="w-4 h-4 mr-2" />
              Size Guide
            </Button>
          </div>
        </div>

        {/* Product Info */}
        <div className="space-y-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              {mockProduct.onSale && (
                <Badge className="bg-red-500">Sale</Badge>
              )}
              {mockProduct.isNew && (
                <Badge className="bg-green-500">New</Badge>
              )}
              <Badge variant="outline">{mockProduct.category}</Badge>
            </div>
            
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              {mockProduct.name}
            </h1>
            
            <div className="flex items-center space-x-4 mb-4">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <span
                    key={i}
                    className={`text-lg ${
                      i < Math.floor(mockProduct.rating) ? 'text-yellow-400' : 'text-gray-300'
                    }`}
                  >
                    ★
                  </span>
                ))}
              </div>
              <span className="text-gray-600">
                {mockProduct.rating} ({mockProduct.reviewCount} reviews)
              </span>
            </div>

            <div className="flex items-center space-x-4">
              <span className="text-3xl font-bold text-indigo-600">
                {mockProduct.price.toLocaleString()} RWF
              </span>
              {mockProduct.originalPrice && (
                <span className="text-xl text-gray-500 line-through">
                  {mockProduct.originalPrice.toLocaleString()} RWF
                </span>
              )}
            </div>
          </div>

          {/* Seller Info */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">{mockProduct.seller.name}</p>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <span>★ {mockProduct.seller.rating}</span>
                    <span>•</span>
                    <span>{mockProduct.seller.totalProducts} products</span>
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  View Store
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Size Selection */}
          <div className="space-y-3">
            <label className="text-sm font-medium">Size</label>
            <div className="grid grid-cols-5 gap-2">
              {mockProduct.sizes.map((size) => (
                <button
                  key={size}
                  onClick={() => setSelectedSize(size)}
                  className={`py-2 px-3 border rounded-md text-sm font-medium ${
                    selectedSize === size
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-600'
                      : 'border-gray-300 hover:border-gray-400'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* Color Selection */}
          <div className="space-y-3">
            <label className="text-sm font-medium">Color</label>
            <Select value={selectedColor} onValueChange={setSelectedColor}>
              <SelectTrigger>
                <SelectValue placeholder="Select a color" />
              </SelectTrigger>
              <SelectContent>
                {mockProduct.colors.map((color) => (
                  <SelectItem key={color} value={color}>
                    {color}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Add to Cart */}
          <div className="flex space-x-4">
            <Button 
              onClick={handleAddToCart} 
              className="flex-1"
              disabled={!mockProduct.inStock}
            >
              <ShoppingCart className="w-4 h-4 mr-2" />
              {t('addToCart')}
            </Button>
            <Button variant="outline" size="icon">
              <Heart className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="icon">
              <Share2 className="w-4 h-4" />
            </Button>
          </div>

          <Separator />

          {/* Product Details Tabs */}
          <Tabs defaultValue="description" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="description">Description</TabsTrigger>
              <TabsTrigger value="specifications">Specifications</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
            </TabsList>
            
            <TabsContent value="description" className="space-y-4">
              <p className="text-gray-600">{mockProduct.description}</p>
              <div>
                <h4 className="font-medium mb-2">Features:</h4>
                <ul className="space-y-1">
                  {mockProduct.features.map((feature, index) => (
                    <li key={index} className="flex items-center text-sm text-gray-600">
                      <span className="w-2 h-2 bg-indigo-600 rounded-full mr-2"></span>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            </TabsContent>
            
            <TabsContent value="specifications" className="space-y-4">
              <div className="space-y-3">
                {Object.entries(mockProduct.specifications).map(([key, value]) => (
                  <div key={key} className="flex justify-between py-2 border-b">
                    <span className="font-medium">{key}:</span>
                    <span className="text-gray-600">{value}</span>
                  </div>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="reviews" className="space-y-4">
              <div className="text-center py-8">
                <p className="text-gray-600">Reviews coming soon...</p>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}