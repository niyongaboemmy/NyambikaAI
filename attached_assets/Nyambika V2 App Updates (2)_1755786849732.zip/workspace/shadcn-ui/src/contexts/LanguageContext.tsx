import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'en' | 'rw' | 'fr';

interface Translations {
  [key: string]: {
    en: string;
    rw: string;
    fr: string;
  };
}

const translations: Translations = {
  welcome: {
    en: 'Welcome to Nyambika',
    rw: 'Murakaza neza kuri Nyambika',
    fr: 'Bienvenue à Nyambika'
  },
  products: {
    en: 'Products',
    rw: 'Ibicuruzwa',
    fr: 'Produits'
  },
  cart: {
    en: 'Cart',
    rw: 'Agasanduku',
    fr: 'Panier'
  },
  profile: {
    en: 'Profile',
    rw: 'Umwirondoro',
    fr: 'Profil'
  },
  login: {
    en: 'Login',
    rw: 'Kwinjira',
    fr: 'Connexion'
  },
  register: {
    en: 'Register',
    rw: 'Kwiyandikisha',
    fr: "S'inscrire"
  },
  virtualTryOn: {
    en: 'Virtual Try-On',
    rw: 'Gerageza mu buryo bwa digitale',
    fr: 'Essayage virtuel'
  },
  addToCart: {
    en: 'Add to Cart',
    rw: 'Shyira mu gasanduku',
    fr: 'Ajouter au panier'
  },
  price: {
    en: 'Price',
    rw: 'Igiciro',
    fr: 'Prix'
  },
  size: {
    en: 'Size',
    rw: 'Ubunini',
    fr: 'Taille'
  },
  color: {
    en: 'Color',
    rw: 'Ibara',
    fr: 'Couleur'
  },
  checkout: {
    en: 'Checkout',
    rw: 'Kwishyura',
    fr: 'Commander'
  },
  orders: {
    en: 'Orders',
    rw: 'Ibisabwa',
    fr: 'Commandes'
  }
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  useEffect(() => {
    const storedLang = localStorage.getItem('nyambika_language') as Language;
    if (storedLang && ['en', 'rw', 'fr'].includes(storedLang)) {
      setLanguage(storedLang);
    }
  }, []);

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('nyambika_language', lang);
  };

  const t = (key: string): string => {
    return translations[key]?.[language] || key;
  };

  return (
    <LanguageContext.Provider value={{
      language,
      setLanguage: handleSetLanguage,
      t
    }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};