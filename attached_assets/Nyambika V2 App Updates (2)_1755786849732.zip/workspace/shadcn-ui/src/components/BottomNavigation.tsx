import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Grid3X3, Camera, ShoppingBag, User } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useCart } from '@/contexts/CartContext';
import { Badge } from '@/components/ui/badge';

const BottomNavigation: React.FC = () => {
  const location = useLocation();
  const { t } = useLanguage();
  const { itemCount } = useCart();

  const isActive = (path: string) => location.pathname === path;

  const navItems = [
    { path: '/', icon: Home, label: 'Home' },
    { path: '/products', icon: Grid3X3, label: t('products') },
    { path: '/virtual-tryon', icon: Camera, label: t('virtualTryOn') },
    { path: '/cart', icon: ShoppingBag, label: t('cart'), badge: itemCount },
    { path: '/profile', icon: User, label: t('profile') },
  ];

  return (
    <nav className="fixed bottom-0 w-full bg-white border-t border-gray-200 z-40">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-around">
          {navItems.map(({ path, icon: Icon, label, badge }) => (
            <Link
              key={path}
              to={path}
              className={`flex flex-col items-center py-3 px-2 text-xs relative ${
                isActive(path) 
                  ? 'text-indigo-600' 
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <Icon className={`w-6 h-6 ${isActive(path) ? 'text-indigo-600' : ''}`} />
              <span className="mt-1 truncate max-w-[60px]">{label}</span>
              {badge && badge > 0 && (
                <Badge 
                  variant="destructive" 
                  className="absolute -top-1 left-1/2 transform -translate-x-1/2 px-1.5 py-0.5 text-xs"
                >
                  {badge}
                </Badge>
              )}
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
};

export default BottomNavigation;