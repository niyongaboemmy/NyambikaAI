import express from 'express';
import Joi from 'joi';
import { PrismaClient } from '@prisma/client';
import { authenticate } from '../middleware/auth';
import { MtnMomoService } from '../services/MtnMomoService';
import { AirtelMoneyService } from '../services/AirtelMoneyService';

const router = express.Router();
const prisma = new PrismaClient();

// Validation schemas
const initiatePaymentSchema = Joi.object({
  orderId: Joi.string().uuid().required(),
  method: Joi.string().valid('MTN_MONEY', 'AIRTEL_MONEY', 'CREDIT_CARD', 'DEBIT_CARD').required(),
  phoneNumber: Joi.when('method', {
    is: Joi.string().valid('MTN_MONEY', 'AIRTEL_MONEY'),
    then: Joi.string().pattern(/^\+250[0-9]{9}$/).required(),
    otherwise: Joi.optional()
  }),
  cardDetails: Joi.when('method', {
    is: Joi.string().valid('CREDIT_CARD', 'DEBIT_CARD'),
    then: Joi.object({
      cardNumber: Joi.string().required(),
      expiryMonth: Joi.string().length(2).required(),
      expiryYear: Joi.string().length(4).required(),
      cvv: Joi.string().length(3).required(),
      holderName: Joi.string().required()
    }).required(),
    otherwise: Joi.optional()
  })
});

const confirmPaymentSchema = Joi.object({
  paymentId: Joi.string().uuid().required(),
  transactionId: Joi.string().required()
});

// Initialize payment services
const mtnMomoService = new MtnMomoService();
const airtelMoneyService = new AirtelMoneyService();

// Initiate payment
router.post('/initiate', authenticate, async (req, res, next) => {
  try {
    const { error, value } = initiatePaymentSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const { orderId, method, phoneNumber, cardDetails } = value;
    const userId = req.user!.id;

    // Verify order belongs to user and is pending payment
    const order = await prisma.order.findFirst({
      where: {
        id: orderId,
        userId,
        paymentStatus: 'PENDING'
      }
    });

    if (!order) {
      return res.status(404).json({ error: 'Order not found or already paid' });
    }

    let paymentResponse;

    // Process payment based on method
    switch (method) {
      case 'MTN_MONEY':
        paymentResponse = await mtnMomoService.initiatePayment({
          amount: order.total,
          phoneNumber: phoneNumber!,
          externalId: `ORDER_${order.orderNumber}`,
          payerMessage: `Payment for order ${order.orderNumber}`,
          payeeNote: `Nyambika order payment`
        });
        break;

      case 'AIRTEL_MONEY':
        paymentResponse = await airtelMoneyService.initiatePayment({
          amount: order.total,
          phoneNumber: phoneNumber!,
          reference: `ORDER_${order.orderNumber}`,
          narration: `Payment for order ${order.orderNumber}`
        });
        break;

      case 'CREDIT_CARD':
      case 'DEBIT_CARD':
        // Integrate with card payment gateway (e.g., Stripe, Flutterwave)
        paymentResponse = {
          success: true,
          transactionId: `CARD_${Date.now()}`,
          status: 'PROCESSING',
          message: 'Card payment processing (demo)'
        };
        break;

      default:
        return res.status(400).json({ error: 'Unsupported payment method' });
    }

    if (!paymentResponse.success) {
      return res.status(400).json({ 
        error: 'Payment initiation failed',
        details: paymentResponse.message 
      });
    }

    // Create payment record
    const payment = await prisma.payment.create({
      data: {
        orderId,
        amount: order.total,
        method: method as any,
        status: 'PROCESSING',
        transactionId: paymentResponse.transactionId,
        externalId: paymentResponse.externalId,
        metadata: {
          phoneNumber,
          cardDetails: cardDetails ? { 
            last4: cardDetails.cardNumber.slice(-4),
            brand: 'VISA' // Detect from card number in real implementation
          } : null,
          provider: method,
          initiatedAt: new Date().toISOString()
        }
      }
    });

    // Update order payment status
    await prisma.order.update({
      where: { id: orderId },
      data: { paymentStatus: 'PROCESSING' }
    });

    res.json({
      message: 'Payment initiated successfully',
      payment: {
        id: payment.id,
        transactionId: payment.transactionId,
        status: payment.status,
        method: payment.method
      },
      instructions: paymentResponse.instructions
    });

  } catch (error) {
    next(error);
  }
});

// Confirm payment (webhook or manual confirmation)
router.post('/confirm', async (req, res, next) => {
  try {
    const { error, value } = confirmPaymentSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const { paymentId, transactionId } = value;

    // Find payment
    const payment = await prisma.payment.findUnique({
      where: { id: paymentId },
      include: { order: true }
    });

    if (!payment) {
      return res.status(404).json({ error: 'Payment not found' });
    }

    // Verify payment with provider
    let verificationResult;
    switch (payment.method) {
      case 'MTN_MONEY':
        verificationResult = await mtnMomoService.verifyPayment(transactionId);
        break;
      case 'AIRTEL_MONEY':
        verificationResult = await airtelMoneyService.verifyPayment(transactionId);
        break;
      default:
        verificationResult = { success: true, status: 'COMPLETED' };
    }

    if (!verificationResult.success) {
      await prisma.payment.update({
        where: { id: paymentId },
        data: { 
          status: 'FAILED',
          metadata: {
            ...payment.metadata as any,
            failureReason: verificationResult.message,
            verifiedAt: new Date().toISOString()
          }
        }
      });

      await prisma.order.update({
        where: { id: payment.orderId },
        data: { paymentStatus: 'FAILED' }
      });

      return res.status(400).json({ error: 'Payment verification failed' });
    }

    // Update payment status
    await prisma.payment.update({
      where: { id: paymentId },
      data: { 
        status: 'COMPLETED',
        metadata: {
          ...payment.metadata as any,
          completedAt: new Date().toISOString(),
          providerResponse: verificationResult.data
        }
      }
    });

    // Update order status
    await prisma.order.update({
      where: { id: payment.orderId },
      data: { 
        paymentStatus: 'COMPLETED',
        status: 'CONFIRMED'
      }
    });

    res.json({
      message: 'Payment confirmed successfully',
      payment: {
        id: payment.id,
        status: 'COMPLETED',
        amount: payment.amount
      }
    });

  } catch (error) {
    next(error);
  }
});

// Get payment history
router.get('/history', authenticate, async (req, res, next) => {
  try {
    const userId = req.user!.id;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const offset = (page - 1) * limit;

    const [payments, total] = await Promise.all([
      prisma.payment.findMany({
        where: {
          order: { userId }
        },
        include: {
          order: {
            select: {
              id: true,
              orderNumber: true,
              total: true,
              createdAt: true
            }
          }
        },
        orderBy: { createdAt: 'desc' },
        skip: offset,
        take: limit
      }),
      prisma.payment.count({
        where: {
          order: { userId }
        }
      })
    ]);

    res.json({
      payments,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    next(error);
  }
});

// Webhook endpoint for MTN MoMo
router.post('/webhook/mtn', async (req, res, next) => {
  try {
    // Verify webhook signature in production
    const { financialTransactionId, externalId, status } = req.body;

    const payment = await prisma.payment.findFirst({
      where: { externalId }
    });

    if (!payment) {
      return res.status(404).json({ error: 'Payment not found' });
    }

    const paymentStatus = status === 'SUCCESSFUL' ? 'COMPLETED' : 'FAILED';

    await prisma.payment.update({
      where: { id: payment.id },
      data: { 
        status: paymentStatus,
        metadata: {
          ...payment.metadata as any,
          webhookData: req.body,
          webhookReceivedAt: new Date().toISOString()
        }
      }
    });

    await prisma.order.update({
      where: { id: payment.orderId },
      data: { 
        paymentStatus,
        ...(paymentStatus === 'COMPLETED' && { status: 'CONFIRMED' })
      }
    });

    res.status(200).json({ message: 'Webhook processed' });

  } catch (error) {
    next(error);
  }
});

// Webhook endpoint for Airtel Money
router.post('/webhook/airtel', async (req, res, next) => {
  try {
    // Process Airtel Money webhook
    const { transaction } = req.body;

    const payment = await prisma.payment.findFirst({
      where: { transactionId: transaction.id }
    });

    if (!payment) {
      return res.status(404).json({ error: 'Payment not found' });
    }

    const paymentStatus = transaction.status === 'TS' ? 'COMPLETED' : 'FAILED';

    await prisma.payment.update({
      where: { id: payment.id },
      data: { 
        status: paymentStatus,
        metadata: {
          ...payment.metadata as any,
          webhookData: req.body,
          webhookReceivedAt: new Date().toISOString()
        }
      }
    });

    await prisma.order.update({
      where: { id: payment.orderId },
      data: { 
        paymentStatus,
        ...(paymentStatus === 'COMPLETED' && { status: 'CONFIRMED' })
      }
    });

    res.status(200).json({ message: 'Webhook processed' });

  } catch (error) {
    next(error);
  }
});

export default router;