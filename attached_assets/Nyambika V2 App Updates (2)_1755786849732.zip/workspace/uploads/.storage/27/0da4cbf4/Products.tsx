import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Search, Filter, Heart } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

// Mock products data
const mockProducts = [
  {
    id: '1',
    name: 'Traditional Rwandan Dress',
    price: 45000,
    originalPrice: 50000,
    image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=400',
    category: 'Traditional',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Red', 'Blue', 'Green'],
    rating: 4.8,
    seller: 'Kigali Fashion House',
    inStock: true,
    isNew: false,
    onSale: true
  },
  {
    id: '2',
    name: 'Modern African Print Top',
    price: 25000,
    image: 'https://images.unsplash.com/photo-1560243563-062bfc001d68?w=400',
    category: 'Casual',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Orange', 'Yellow', 'Purple'],
    rating: 4.5,
    seller: 'Afrique Styles',
    inStock: true,
    isNew: true,
    onSale: false
  },
  {
    id: '3',
    name: 'Elegant Evening Gown',
    price: 75000,
    image: 'https://images.unsplash.com/photo-1566479179817-0b8c736fa257?w=400',
    category: 'Formal',
    sizes: ['XS', 'S', 'M', 'L'],
    colors: ['Black', 'Navy', 'Wine'],
    rating: 4.9,
    seller: 'Elegance Rwanda',
    inStock: true,
    isNew: false,
    onSale: false
  },
  {
    id: '4',
    name: 'Casual Summer Outfit',
    price: 35000,
    originalPrice: 40000,
    image: 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=400',
    category: 'Summer',
    sizes: ['S', 'M', 'L'],
    colors: ['White', 'Pink', 'Light Blue'],
    rating: 4.6,
    seller: 'Summer Vibes RW',
    inStock: true,
    isNew: false,
    onSale: true
  },
  {
    id: '5',
    name: 'Business Formal Suit',
    price: 95000,
    image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=400',
    category: 'Formal',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Black', 'Charcoal', 'Navy'],
    rating: 4.7,
    seller: 'Professional Wear',
    inStock: false,
    isNew: true,
    onSale: false
  },
  {
    id: '6',
    name: 'Kitenge Maxi Dress',
    price: 40000,
    image: 'https://images.unsplash.com/photo-1566479179817-0b8c736fa257?w=400',
    category: 'Traditional',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Multi-color'],
    rating: 4.8,
    seller: 'Heritage Fashion',
    inStock: true,
    isNew: false,
    onSale: false
  }
];

const categories = ['All', 'Traditional', 'Casual', 'Formal', 'Summer'];
const sortOptions = [
  { value: 'newest', label: 'Newest' },
  { value: 'price-low', label: 'Price: Low to High' },
  { value: 'price-high', label: 'Price: High to Low' },
  { value: 'rating', label: 'Rating' },
];

export default function Products() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [sortBy, setSortBy] = useState('newest');
  const [priceRange, setPriceRange] = useState([0, 100000]);
  const [showFilters, setShowFilters] = useState(false);
  const { t } = useLanguage();

  const filteredAndSortedProducts = useMemo(() => {
    let filtered = mockProducts.filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           product.seller.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
      const matchesPrice = product.price >= priceRange[0] && product.price <= priceRange[1];
      
      return matchesSearch && matchesCategory && matchesPrice;
    });

    // Sort products
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'price-low':
          return a.price - b.price;
        case 'price-high':
          return b.price - a.price;
        case 'rating':
          return b.rating - a.rating;
        case 'newest':
        default:
          return b.isNew ? 1 : -1;
      }
    });

    return filtered;
  }, [searchTerm, selectedCategory, sortBy, priceRange]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{t('products')}</h1>
        <p className="text-gray-600">Discover amazing fashion from Rwanda's top designers and brands</p>
      </div>

      {/* Search and Filters */}
      <div className="space-y-4 mb-8">
        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <Input
            type="text"
            placeholder="Search products, brands..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-12 py-3 text-lg"
          />
        </div>

        {/* Filter Toggle and Sort */}
        <div className="flex flex-col sm:flex-row gap-4 justify-between">
          <Button
            variant="outline"
            onClick={() => setShowFilters(!showFilters)}
            className="sm:w-auto w-full"
          >
            <Filter className="w-4 h-4 mr-2" />
            Filters
          </Button>
          
          <div className="flex gap-2">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {sortOptions.map(option => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Filter Panel */}
        {showFilters && (
          <Card className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Category Filter */}
              <div>
                <Label className="text-sm font-medium mb-3 block">Category</Label>
                <div className="space-y-2">
                  {categories.map(category => (
                    <button
                      key={category}
                      onClick={() => setSelectedCategory(category)}
                      className={`block w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${
                        selectedCategory === category
                          ? 'bg-indigo-100 text-indigo-700'
                          : 'hover:bg-gray-100'
                      }`}
                    >
                      {category}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price Range Filter */}
              <div>
                <Label className="text-sm font-medium mb-3 block">
                  Price Range: {priceRange[0].toLocaleString()} - {priceRange[1].toLocaleString()} RWF
                </Label>
                <Slider
                  value={priceRange}
                  onValueChange={setPriceRange}
                  max={100000}
                  min={0}
                  step={5000}
                  className="mb-2"
                />
              </div>
            </div>
          </Card>
        )}
      </div>

      {/* Results Count */}
      <div className="mb-6">
        <p className="text-gray-600">
          {filteredAndSortedProducts.length} product{filteredAndSortedProducts.length !== 1 ? 's' : ''} found
        </p>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredAndSortedProducts.map((product) => (
          <Card key={product.id} className="group hover:shadow-lg transition-all duration-300 overflow-hidden">
            <div className="relative aspect-square overflow-hidden">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              
              {/* Badges */}
              <div className="absolute top-3 left-3 flex flex-col gap-2">
                {product.isNew && (
                  <Badge className="bg-green-500 hover:bg-green-600">New</Badge>
                )}
                {product.onSale && (
                  <Badge className="bg-red-500 hover:bg-red-600">Sale</Badge>
                )}
                {!product.inStock && (
                  <Badge variant="secondary">Out of Stock</Badge>
                )}
              </div>

              {/* Wishlist Button */}
              <Button
                variant="ghost"
                size="sm"
                className="absolute top-3 right-3 bg-white/80 hover:bg-white"
              >
                <Heart className="w-4 h-4" />
              </Button>
            </div>

            <CardContent className="p-4">
              <div className="mb-2">
                <Badge variant="outline" className="text-xs">
                  {product.category}
                </Badge>
              </div>
              
              <h3 className="font-semibold text-lg mb-1 line-clamp-2">
                {product.name}
              </h3>
              
              <p className="text-sm text-gray-600 mb-2">by {product.seller}</p>
              
              <div className="flex items-center mb-3">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <span
                      key={i}
                      className={`text-sm ${
                        i < Math.floor(product.rating) ? 'text-yellow-400' : 'text-gray-300'
                      }`}
                    >
                      ★
                    </span>
                  ))}
                </div>
                <span className="text-sm text-gray-600 ml-2">({product.rating})</span>
              </div>

              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <span className="text-xl font-bold text-indigo-600">
                    {product.price.toLocaleString()} RWF
                  </span>
                  {product.originalPrice && (
                    <span className="text-sm text-gray-500 line-through">
                      {product.originalPrice.toLocaleString()} RWF
                    </span>
                  )}
                </div>
              </div>

              <Button asChild className="w-full" disabled={!product.inStock}>
                <Link to={`/products/${product.id}`}>
                  {product.inStock ? 'View Details' : 'Out of Stock'}
                </Link>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Empty State */}
      {filteredAndSortedProducts.length === 0 && (
        <div className="text-center py-16">
          <div className="text-gray-400 text-6xl mb-4">🔍</div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No products found</h3>
          <p className="text-gray-600 mb-4">
            Try adjusting your filters or search terms
          </p>
          <Button onClick={() => {
            setSearchTerm('');
            setSelectedCategory('All');
            setPriceRange([0, 100000]);
          }}>
            Clear Filters
          </Button>
        </div>
      )}
    </div>
  );
}