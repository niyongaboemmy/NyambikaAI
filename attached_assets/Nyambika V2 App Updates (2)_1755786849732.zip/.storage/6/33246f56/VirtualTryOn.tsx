import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Camera, Upload, Sparkles, Download, RotateCcw } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { toast } from 'sonner';

// Mock clothing items for try-on
const clothingItems = [
  {
    id: '1',
    name: 'Traditional Rwandan Dress',
    image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=300',
    category: 'Traditional'
  },
  {
    id: '2',
    name: 'Modern African Print Top',
    image: 'https://images.unsplash.com/photo-1560243563-062bfc001d68?w=300',
    category: 'Casual'
  },
  {
    id: '3',
    name: 'Elegant Evening Gown',
    image: '/images/EveningGown.jpg',
    category: 'Formal'
  }
];

export default function VirtualTryOn() {
  const [userPhoto, setUserPhoto] = useState<string | null>(null);
  const [selectedClothing, setSelectedClothing] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [tryOnResult, setTryOnResult] = useState<string | null>(null);
  const [measurements, setMeasurements] = useState({
    height: '',
    weight: '',
    chest: '',
    waist: '',
    shoulders: ''
  });
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { t } = useLanguage();

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error('Photo size must be less than 5MB');
        return;
      }
      
      const reader = new FileReader();
      reader.onload = (e) => {
        setUserPhoto(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCameraCapture = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      toast.success('Camera access granted! (Demo: Use upload instead)');
      stream.getTracks().forEach(track => track.stop());
    } catch (error) {
      toast.error('Camera access denied. Please upload a photo instead.');
    }
  };

  const handleVirtualTryOn = async () => {
    if (!userPhoto || !selectedClothing) {
      toast.error('Please upload a photo and select clothing item');
      return;
    }

    setIsProcessing(true);
    
    // Simulate AI processing
    setTimeout(() => {
      setTryOnResult('/images/virtualtryon.jpg');
      setIsProcessing(false);
      toast.success('Virtual try-on completed!');
    }, 3000);
  };

  const getSizeRecommendation = () => {
    if (!measurements.height || !measurements.weight) {
      toast.error('Please enter height and weight for size recommendation');
      return;
    }

    const height = parseInt(measurements.height);
    const weight = parseInt(measurements.weight);
    const bmi = weight / ((height / 100) ** 2);

    let recommendedSize = 'M';
    if (bmi < 18.5) recommendedSize = 'S';
    else if (bmi > 25) recommendedSize = 'L';
    else if (bmi > 30) recommendedSize = 'XL';

    toast.success(`Recommended size: ${recommendedSize}`);
  };

  const selectedClothingItem = clothingItems.find(item => item.id === selectedClothing);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{t('virtualTryOn')}</h1>
        <p className="text-gray-600">
          Experience how clothes look on you with our AI-powered virtual try-on technology
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Panel - Upload & Controls */}
        <div className="space-y-6">
          {/* Photo Upload Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Upload className="w-5 h-5 mr-2" />
                Upload Your Photo
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                {userPhoto ? (
                  <div className="space-y-4">
                    <img 
                      src={userPhoto} 
                      alt="User photo" 
                      className="max-w-full max-h-64 mx-auto rounded-lg"
                    />
                    <Button 
                      variant="outline" 
                      onClick={() => setUserPhoto(null)}
                    >
                      <RotateCcw className="w-4 h-4 mr-2" />
                      Replace Photo
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="text-gray-400 text-6xl">📸</div>
                    <div>
                      <p className="text-lg font-medium mb-2">Upload a full-body photo</p>
                      <p className="text-sm text-gray-600 mb-4">
                        For best results, stand straight facing the camera
                      </p>
                      <div className="flex flex-col sm:flex-row gap-2 justify-center">
                        <Button onClick={() => fileInputRef.current?.click()}>
                          <Upload className="w-4 h-4 mr-2" />
                          Upload Photo
                        </Button>
                        <Button variant="outline" onClick={handleCameraCapture}>
                          <Camera className="w-4 h-4 mr-2" />
                          Use Camera
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                className="hidden"
              />
            </CardContent>
          </Card>

          {/* Clothing Selection */}
          <Card>
            <CardHeader>
              <CardTitle>Select Clothing Item</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select value={selectedClothing} onValueChange={setSelectedClothing}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a clothing item" />
                </SelectTrigger>
                <SelectContent>
                  {clothingItems.map((item) => (
                    <SelectItem key={item.id} value={item.id}>
                      {item.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {selectedClothingItem && (
                <div className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                  <img 
                    src={selectedClothingItem.image} 
                    alt={selectedClothingItem.name}
                    className="w-16 h-16 rounded-lg object-cover"
                  />
                  <div>
                    <p className="font-medium">{selectedClothingItem.name}</p>
                    <p className="text-sm text-gray-600">{selectedClothingItem.category}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Measurements for Size Recommendation */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Sparkles className="w-5 h-5 mr-2" />
                Size Recommendation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="height">Height (cm)</Label>
                  <Input
                    id="height"
                    type="number"
                    placeholder="170"
                    value={measurements.height}
                    onChange={(e) => setMeasurements(prev => ({...prev, height: e.target.value}))}
                  />
                </div>
                <div>
                  <Label htmlFor="weight">Weight (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder="65"
                    value={measurements.weight}
                    onChange={(e) => setMeasurements(prev => ({...prev, weight: e.target.value}))}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="chest">Chest (cm)</Label>
                  <Input
                    id="chest"
                    type="number"
                    placeholder="90"
                    value={measurements.chest}
                    onChange={(e) => setMeasurements(prev => ({...prev, chest: e.target.value}))}
                  />
                </div>
                <div>
                  <Label htmlFor="waist">Waist (cm)</Label>
                  <Input
                    id="waist"
                    type="number"
                    placeholder="75"
                    value={measurements.waist}
                    onChange={(e) => setMeasurements(prev => ({...prev, waist: e.target.value}))}
                  />
                </div>
                <div>
                  <Label htmlFor="shoulders">Shoulders (cm)</Label>
                  <Input
                    id="shoulders"
                    type="number"
                    placeholder="40"
                    value={measurements.shoulders}
                    onChange={(e) => setMeasurements(prev => ({...prev, shoulders: e.target.value}))}
                  />
                </div>
              </div>

              <Button onClick={getSizeRecommendation} variant="outline" className="w-full">
                Get Size Recommendation
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Right Panel - Results */}
        <div className="space-y-6">
          <Card className="h-full">
            <CardHeader>
              <CardTitle>Virtual Try-On Result</CardTitle>
            </CardHeader>
            <CardContent className="h-96">
              {tryOnResult ? (
                <div className="space-y-4">
                  <img 
                    src={tryOnResult} 
                    alt="Try-on result" 
                    className="w-full h-80 object-cover rounded-lg"
                  />
                  <div className="flex space-x-2">
                    <Button className="flex-1">
                      <Download className="w-4 h-4 mr-2" />
                      Download Result
                    </Button>
                    <Button variant="outline" onClick={() => setTryOnResult(null)}>
                      Try Another
                    </Button>
                  </div>
                </div>
              ) : isProcessing ? (
                <div className="flex flex-col items-center justify-center h-full">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mb-4"></div>
                  <p className="text-lg font-medium">Processing your virtual try-on...</p>
                  <p className="text-sm text-gray-600">This may take a few moments</p>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-gray-400">
                  <Sparkles className="w-16 h-16 mb-4" />
                  <p className="text-lg font-medium">Ready for virtual try-on</p>
                  <p className="text-sm text-center">
                    Upload your photo and select clothing to see the magic happen
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Try-On Button */}
          <Button 
            onClick={handleVirtualTryOn}
            disabled={!userPhoto || !selectedClothing || isProcessing}
            className="w-full h-12 text-lg"
          >
            {isProcessing ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Processing...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 mr-2" />
                Start Virtual Try-On
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Tips Section */}
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Tips for Best Results</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Camera className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="font-medium mb-1">Good Lighting</h3>
              <p className="text-sm text-gray-600">Use natural lighting or bright indoor lights</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <span className="text-green-600 text-xl">🧍</span>
              </div>
              <h3 className="font-medium mb-1">Stand Straight</h3>
              <p className="text-sm text-gray-600">Face the camera directly with arms at your sides</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <span className="text-purple-600 text-xl">👕</span>
              </div>
              <h3 className="font-medium mb-1">Fitted Clothing</h3>
              <p className="text-sm text-gray-600">Wear fitted clothes for better body detection</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}