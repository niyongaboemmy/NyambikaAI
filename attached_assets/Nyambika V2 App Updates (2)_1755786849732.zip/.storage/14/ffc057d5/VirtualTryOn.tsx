import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Camera, Upload, Sparkles, Download, RotateCcw, Shirt, Zap } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { toast } from 'sonner';

// Enhanced clothing items with local images
const clothingItems = [
  {
    id: '1',
    name: 'Traditional Rwandan Dress',
    image: '/images/TraditionalClothing.jpg',
    category: 'Traditional',
    price: '$85',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Red', 'Blue', 'Green', 'Gold']
  },
  {
    id: '2',
    name: 'Elegant Evening Gown',
    image: '/images/EveningGown.jpg',
    category: 'Formal',
    price: '$120',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Black', 'Navy', 'Burgundy', 'Silver']
  },
  {
    id: '3',
    name: 'Elegant Modern Gown',
    image: '/images/ElegantGown.jpg',
    category: 'Evening',
    price: '$95',
    sizes: ['XS', 'S', 'M', 'L'],
    colors: ['White', 'Cream', 'Rose Gold', 'Champagne']
  }
];

export default function VirtualTryOn() {
  const [userPhoto, setUserPhoto] = useState<string | null>(null);
  const [selectedClothing, setSelectedClothing] = useState('');
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [tryOnResult, setTryOnResult] = useState<string | null>(null);
  const [aiAnalysis, setAiAnalysis] = useState<string>('');
  const [measurements, setMeasurements] = useState({
    height: '',
    weight: '',
    chest: '',
    waist: '',
    shoulders: ''
  });
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { t } = useLanguage();

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        toast.error('Photo size must be less than 10MB');
        return;
      }
      
      const reader = new FileReader();
      reader.onload = (e) => {
        setUserPhoto(e.target?.result as string);
        setTryOnResult(null);
        toast.success('Photo uploaded successfully!');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCameraCapture = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          width: { ideal: 640 },
          height: { ideal: 480 }
        } 
      });
      
      // Create video element for camera preview
      const video = document.createElement('video');
      video.srcObject = stream;
      video.autoplay = true;
      
      // For demo purposes, we'll just show success message
      // In real implementation, you'd create a camera modal
      toast.success('Camera access granted! Use upload for now (camera feature coming soon)');
      
      // Stop the stream
      stream.getTracks().forEach(track => track.stop());
    } catch (error) {
      toast.error('Camera access denied. Please upload a photo instead.');
    }
  };

  const enhancedSizeRecommendation = () => {
    if (!measurements.height || !measurements.weight) {
      toast.error('Please enter height and weight for size recommendation');
      return;
    }

    const height = parseInt(measurements.height);
    const weight = parseInt(measurements.weight);
    const chest = parseInt(measurements.chest) || 0;
    const waist = parseInt(measurements.waist) || 0;
    const shoulders = parseInt(measurements.shoulders) || 0;
    
    const bmi = weight / ((height / 100) ** 2);
    let recommendedSize = 'M';
    let confidence = 85;

    // Enhanced algorithm considering multiple measurements
    if (chest && waist && shoulders) {
      // More accurate sizing based on all measurements
      if (chest < 85 && waist < 70 && shoulders < 38) {
        recommendedSize = 'XS';
        confidence = 95;
      } else if (chest < 90 && waist < 75 && shoulders < 40) {
        recommendedSize = 'S';
        confidence = 92;
      } else if (chest < 95 && waist < 80 && shoulders < 42) {
        recommendedSize = 'M';
        confidence = 90;
      } else if (chest < 100 && waist < 85 && shoulders < 44) {
        recommendedSize = 'L';
        confidence = 88;
      } else {
        recommendedSize = 'XL';
        confidence = 85;
      }
    } else {
      // Fallback to BMI-based sizing
      if (bmi < 18.5) recommendedSize = 'S';
      else if (bmi > 25) recommendedSize = 'L';
      else if (bmi > 30) recommendedSize = 'XL';
      confidence = 75;
    }

    setSelectedSize(recommendedSize);
    toast.success(`Recommended size: ${recommendedSize} (${confidence}% confidence)`);
  };

  const handleVirtualTryOn = async () => {
    if (!userPhoto || !selectedClothing) {
      toast.error('Please upload a photo and select clothing item');
      return;
    }

    setIsProcessing(true);
    setAiAnalysis('');
    
    // Simulate realistic AI processing with steps
    const steps = [
      'Analyzing body measurements...',
      'Detecting clothing fit points...',
      'Applying virtual fabric physics...',
      'Adjusting lighting and shadows...',
      'Generating final result...'
    ];

    for (let i = 0; i < steps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 800));
      setAiAnalysis(steps[i]);
    }

    // Enhanced result generation with canvas manipulation
    generateEnhancedTryOnResult();
    
    setTimeout(() => {
      setIsProcessing(false);
      setAiAnalysis('Virtual try-on complete!');
      toast.success('Virtual try-on completed! Result generated with AI enhancement.');
    }, 1000);
  };

  const generateEnhancedTryOnResult = () => {
    const canvas = canvasRef.current;
    const selectedItem = clothingItems.find(item => item.id === selectedClothing);
    
    if (canvas && userPhoto && selectedItem) {
      const ctx = canvas.getContext('2d');
      const userImg = new Image();
      const clothingImg = new Image();
      
      userImg.onload = () => {
        canvas.width = 400;
        canvas.height = 600;
        
        // Draw user photo
        ctx?.drawImage(userImg, 0, 0, 400, 600);
        
        clothingImg.onload = () => {
          // Simple overlay effect (in real app, this would be much more sophisticated)
          if (ctx) {
            ctx.globalAlpha = 0.7;
            ctx.drawImage(clothingImg, 50, 150, 300, 400);
            ctx.globalAlpha = 1.0;
            
            // Add some visual effects
            ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
            ctx.fillRect(0, 0, 400, 600);
          }
          
          // Convert canvas to data URL for display
          setTryOnResult(canvas.toDataURL());
        };
        
        clothingImg.src = selectedItem.image;
      };
      
      userImg.src = userPhoto;
    } else {
      // Fallback to showing the clothing item
      setTryOnResult('/images/virtualtryon.jpg');
    }
  };

  const downloadResult = () => {
    if (tryOnResult) {
      const link = document.createElement('a');
      link.download = `nyambika-virtual-tryon-${Date.now()}.jpg`;
      link.href = tryOnResult;
      link.click();
      toast.success('Result downloaded successfully!');
    }
  };

  const selectedClothingItem = clothingItems.find(item => item.id === selectedClothing);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2 flex items-center justify-center">
          <Shirt className="w-8 h-8 mr-3 text-indigo-600" />
          {t('virtualTryOn')}
        </h1>
        <p className="text-muted-foreground">
          Experience how clothes look on you with our AI-powered virtual try-on technology
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Panel - Upload & Controls */}
        <div className="space-y-6">
          {/* Photo Upload Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Upload className="w-5 h-5 mr-2" />
                Upload Your Photo
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border-2 border-dashed border-border rounded-lg p-8 text-center bg-muted/20">
                {userPhoto ? (
                  <div className="space-y-4">
                    <img 
                      src={userPhoto} 
                      alt="User photo" 
                      className="max-w-full max-h-64 mx-auto rounded-lg shadow-lg"
                    />
                    <Button 
                      variant="outline" 
                      onClick={() => setUserPhoto(null)}
                    >
                      <RotateCcw className="w-4 h-4 mr-2" />
                      Replace Photo
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="text-muted-foreground text-6xl">📸</div>
                    <div>
                      <p className="text-lg font-medium mb-2">Upload a full-body photo</p>
                      <p className="text-sm text-muted-foreground mb-4">
                        For best results, stand straight facing the camera with good lighting
                      </p>
                      <div className="flex flex-col sm:flex-row gap-2 justify-center">
                        <Button onClick={() => fileInputRef.current?.click()}>
                          <Upload className="w-4 h-4 mr-2" />
                          Upload Photo
                        </Button>
                        <Button variant="outline" onClick={handleCameraCapture}>
                          <Camera className="w-4 h-4 mr-2" />
                          Use Camera
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                className="hidden"
              />
            </CardContent>
          </Card>

          {/* Clothing Selection */}
          <Card>
            <CardHeader>
              <CardTitle>Select Clothing Item</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select value={selectedClothing} onValueChange={setSelectedClothing}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a clothing item" />
                </SelectTrigger>
                <SelectContent>
                  {clothingItems.map((item) => (
                    <SelectItem key={item.id} value={item.id}>
                      {item.name} - {item.price}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {selectedClothingItem && (
                <div className="space-y-4">
                  <div className="flex items-center space-x-4 p-3 bg-muted rounded-lg">
                    <img 
                      src={selectedClothingItem.image} 
                      alt={selectedClothingItem.name}
                      className="w-16 h-16 rounded-lg object-cover"
                    />
                    <div>
                      <p className="font-medium">{selectedClothingItem.name}</p>
                      <p className="text-sm text-muted-foreground">{selectedClothingItem.category} • {selectedClothingItem.price}</p>
                    </div>
                  </div>
                  
                  {/* Size and Color Selection */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="size">Size</Label>
                      <Select value={selectedSize} onValueChange={setSelectedSize}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select size" />
                        </SelectTrigger>
                        <SelectContent>
                          {selectedClothingItem.sizes.map((size) => (
                            <SelectItem key={size} value={size}>
                              {size}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="color">Color</Label>
                      <Select value={selectedColor} onValueChange={setSelectedColor}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select color" />
                        </SelectTrigger>
                        <SelectContent>
                          {selectedClothingItem.colors.map((color) => (
                            <SelectItem key={color} value={color}>
                              {color}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Enhanced Measurements for Size Recommendation */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Zap className="w-5 h-5 mr-2" />
                Smart Size Recommendation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="height">Height (cm)</Label>
                  <Input
                    id="height"
                    type="number"
                    placeholder="170"
                    value={measurements.height}
                    onChange={(e) => setMeasurements(prev => ({...prev, height: e.target.value}))}
                  />
                </div>
                <div>
                  <Label htmlFor="weight">Weight (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder="65"
                    value={measurements.weight}
                    onChange={(e) => setMeasurements(prev => ({...prev, weight: e.target.value}))}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="chest">Chest (cm)</Label>
                  <Input
                    id="chest"
                    type="number"
                    placeholder="90"
                    value={measurements.chest}
                    onChange={(e) => setMeasurements(prev => ({...prev, chest: e.target.value}))}
                  />
                </div>
                <div>
                  <Label htmlFor="waist">Waist (cm)</Label>
                  <Input
                    id="waist"
                    type="number"
                    placeholder="75"
                    value={measurements.waist}
                    onChange={(e) => setMeasurements(prev => ({...prev, waist: e.target.value}))}
                  />
                </div>
                <div>
                  <Label htmlFor="shoulders">Shoulders (cm)</Label>
                  <Input
                    id="shoulders"
                    type="number"
                    placeholder="40"
                    value={measurements.shoulders}
                    onChange={(e) => setMeasurements(prev => ({...prev, shoulders: e.target.value}))}
                  />
                </div>
              </div>

              <Button onClick={enhancedSizeRecommendation} variant="outline" className="w-full">
                <Sparkles className="w-4 h-4 mr-2" />
                Get AI Size Recommendation
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Right Panel - Results */}
        <div className="space-y-6">
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Virtual Try-On Result
                {aiAnalysis && (
                  <span className="text-sm text-muted-foreground">{aiAnalysis}</span>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="h-96">
              {tryOnResult ? (
                <div className="space-y-4">
                  <img 
                    src={tryOnResult} 
                    alt="Try-on result" 
                    className="w-full h-80 object-cover rounded-lg shadow-lg"
                  />
                  <div className="flex space-x-2">
                    <Button className="flex-1" onClick={downloadResult}>
                      <Download className="w-4 h-4 mr-2" />
                      Download Result
                    </Button>
                    <Button variant="outline" onClick={() => setTryOnResult(null)}>
                      Try Another
                    </Button>
                  </div>
                </div>
              ) : isProcessing ? (
                <div className="flex flex-col items-center justify-center h-full">
                  <div className="relative">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mb-4"></div>
                    <Sparkles className="absolute top-3 left-3 w-6 h-6 text-indigo-600 animate-pulse" />
                  </div>
                  <p className="text-lg font-medium">Processing your virtual try-on...</p>
                  <p className="text-sm text-muted-foreground text-center mt-2">
                    {aiAnalysis || 'Preparing AI algorithms...'}
                  </p>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                  <Sparkles className="w-16 h-16 mb-4" />
                  <p className="text-lg font-medium">Ready for virtual try-on</p>
                  <p className="text-sm text-center">
                    Upload your photo and select clothing to see the magic happen
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Try-On Button */}
          <Button 
            onClick={handleVirtualTryOn}
            disabled={!userPhoto || !selectedClothing || isProcessing}
            className="w-full h-12 text-lg"
          >
            {isProcessing ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Processing...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 mr-2" />
                Start Virtual Try-On
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Hidden canvas for image processing */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Enhanced Tips Section */}
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Tips for Best Results</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Camera className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="font-medium mb-1">Good Lighting</h3>
              <p className="text-sm text-muted-foreground">Use natural lighting or bright indoor lights</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center mx-auto mb-2">
                <span className="text-green-600 dark:text-green-400 text-xl">🧍</span>
              </div>
              <h3 className="font-medium mb-1">Stand Straight</h3>
              <p className="text-sm text-muted-foreground">Face the camera directly with arms at your sides</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center mx-auto mb-2">
                <span className="text-purple-600 dark:text-purple-400 text-xl">👕</span>
              </div>
              <h3 className="font-medium mb-1">Fitted Clothing</h3>
              <p className="text-sm text-muted-foreground">Wear fitted clothes for better body detection</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Zap className="w-6 h-6 text-orange-600 dark:text-orange-400" />
              </div>
              <h3 className="font-medium mb-1">Measurements</h3>
              <p className="text-sm text-muted-foreground">Add measurements for accurate size recommendations</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}