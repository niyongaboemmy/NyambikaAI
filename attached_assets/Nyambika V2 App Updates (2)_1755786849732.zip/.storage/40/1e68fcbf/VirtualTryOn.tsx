import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Camera, Upload, Sparkles, Download, RotateCcw, Shirt, Zap, Play, Square, Maximize2 } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { toast } from 'sonner';

const clothingItems = [
  {
    id: '1',
    name: 'Traditional Rwandan Dress',
    image: '/images/TraditionalClothing.jpg',
    category: 'Traditional',
    price: '$85',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Red', 'Blue', 'Green', 'Gold'],
    overlay: {
      type: 'dress',
      position: { x: 0.2, y: 0.3, width: 0.6, height: 0.6 }
    }
  },
  {
    id: '2',
    name: 'Elegant Evening Gown',
    image: '/images/EveningGown.jpg',
    category: 'Formal',
    price: '$120',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Black', 'Navy', 'Burgundy', 'Silver'],
    overlay: {
      type: 'gown',
      position: { x: 0.15, y: 0.25, width: 0.7, height: 0.7 }
    }
  },
  {
    id: '3',
    name: 'Elegant Modern Gown',
    image: '/images/ElegantGown.jpg',
    category: 'Evening',
    price: '$95',
    sizes: ['XS', 'S', 'M', 'L'],
    colors: ['White', 'Cream', 'Rose Gold', 'Champagne'],
    overlay: {
      type: 'modern',
      position: { x: 0.25, y: 0.2, width: 0.5, height: 0.75 }
    }
  },
  {
    id: '4',
    name: 'Virtual Sunglasses',
    image: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjQwIiB2aWV3Qm94PSIwIDAgMTAwIDQwIiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8cGF0aCBkPSJNMTAgMTBIMzkuNUw0NSAyMEgzNUwzMCAzMEg5TDEwIDEwWiIgZmlsbD0iIzAwMCIgb3BhY2l0eT0iMC44Ii8+CjxwYXRoIGQ9Ik02MCA4SDg5LjVMOTAgMzBINjlMNjUgMjBINTVMNjAgOFoiIGZpbGw9IiMwMDAiIG9wYWNpdHk9IjAuOCIvPgo8cGF0aCBkPSJNNDUgMjBINTUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIyIi8+Cjwvc3ZnPgo=',
    category: 'Accessories',
    price: '$45',
    sizes: ['One Size'],
    colors: ['Black', 'Brown', 'Silver'],
    overlay: {
      type: 'glasses',
      position: { x: 0.3, y: 0.1, width: 0.4, height: 0.1 }
    }
  }
];

export default function VirtualTryOn() {
  const [selectedClothing, setSelectedClothing] = useState('');
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamInitialized, setStreamInitialized] = useState(false);
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const overlayCanvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animationFrameRef = useRef<number>();
  
  const { t } = useLanguage();

  // Face detection simulation (in real app, you'd use TensorFlow.js or MediaPipe)
  const detectFaceAndBody = useCallback(() => {
    return {
      face: { x: 0.3, y: 0.1, width: 0.4, height: 0.3 },
      body: { x: 0.2, y: 0.3, width: 0.6, height: 0.6 }
    };
  }, []);

  // Real-time overlay rendering
  const renderOverlay = useCallback(() => {
    if (!videoRef.current || !overlayCanvasRef.current || !selectedClothing || !isStreaming) {
      return;
    }

    const video = videoRef.current;
    const canvas = overlayCanvasRef.current;
    const ctx = canvas.getContext('2d');
    
    if (!ctx) return;

    // Set canvas size to match video
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;

    // Clear previous frame
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Get selected clothing item
    const clothingItem = clothingItems.find(item => item.id === selectedClothing);
    if (!clothingItem) return;

    // Simulate face/body detection
    const detection = detectFaceAndBody();
    
    // Calculate overlay position based on detection
    let overlayX, overlayY, overlayWidth, overlayHeight;
    
    if (clothingItem.overlay.type === 'glasses') {
      // Position glasses on detected face
      overlayX = detection.face.x * canvas.width;
      overlayY = detection.face.y * canvas.height + (detection.face.height * 0.3 * canvas.height);
      overlayWidth = detection.face.width * canvas.width;
      overlayHeight = clothingItem.overlay.position.height * canvas.height;
    } else {
      // Position clothing on detected body
      overlayX = clothingItem.overlay.position.x * canvas.width;
      overlayY = clothingItem.overlay.position.y * canvas.height;
      overlayWidth = clothingItem.overlay.position.width * canvas.width;
      overlayHeight = clothingItem.overlay.position.height * canvas.height;
    }

    // Create and draw clothing overlay
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      ctx.globalAlpha = 0.8;
      ctx.drawImage(img, overlayX, overlayY, overlayWidth, overlayHeight);
      ctx.globalAlpha = 1.0;

      // Add some visual effects
      if (clothingItem.overlay.type === 'glasses') {
        // Add reflection effect for glasses
        ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.fillRect(overlayX, overlayY, overlayWidth * 0.4, overlayHeight * 0.6);
        ctx.fillRect(overlayX + overlayWidth * 0.6, overlayY, overlayWidth * 0.4, overlayHeight * 0.6);
      }
    };
    
    // Use base64 image for glasses or try to load clothing image
    if (clothingItem.overlay.type === 'glasses') {
      img.src = clothingItem.image;
    } else {
      // For clothing, create a colored rectangle as simulation
      const colorMap: Record<string, string> = {
        'Red': '#dc2626',
        'Blue': '#2563eb',
        'Green': '#16a34a',
        'Gold': '#ca8a04',
        'Black': '#000000',
        'Navy': '#1e3a8a',
        'Burgundy': '#991b1b',
        'Silver': '#6b7280',
        'White': '#ffffff',
        'Cream': '#fef3c7',
        'Rose Gold': '#f59e0b',
        'Champagne': '#fde68a'
      };
      
      const color = selectedColor && colorMap[selectedColor] ? colorMap[selectedColor] : '#3b82f6';
      
      ctx.fillStyle = color;
      ctx.globalAlpha = 0.6;
      ctx.fillRect(overlayX, overlayY, overlayWidth, overlayHeight);
      
      // Add pattern for clothing texture
      ctx.globalAlpha = 0.3;
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      for (let i = 0; i < overlayWidth; i += 20) {
        ctx.beginPath();
        ctx.moveTo(overlayX + i, overlayY);
        ctx.lineTo(overlayX + i, overlayY + overlayHeight);
        ctx.stroke();
      }
      ctx.globalAlpha = 1.0;
    }

    // Continue animation
    if (isStreaming) {
      animationFrameRef.current = requestAnimationFrame(renderOverlay);
    }
  }, [selectedClothing, selectedColor, isStreaming, detectFaceAndBody]);

  // Start camera stream
  const startCamera = async () => {
    try {
      const constraints = {
        video: {
          width: { ideal: 1280, max: 1920 },
          height: { ideal: 720, max: 1080 },
          facingMode: facingMode,
          frameRate: { ideal: 30 }
        },
        audio: false
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        
        videoRef.current.onloadedmetadata = () => {
          setStreamInitialized(true);
          setIsStreaming(true);
          toast.success('Camera started! Select clothing to see virtual try-on');
        };
      }
    } catch (error) {
      console.error('Camera access error:', error);
      toast.error('Camera access denied. Please allow camera permissions and try again.');
    }
  };

  // Stop camera stream
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }
    
    setIsStreaming(false);
    setStreamInitialized(false);
    
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    
    toast.info('Camera stopped');
  };

  // Capture photo
  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current || !overlayCanvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const overlayCanvas = overlayCanvasRef.current;
    const ctx = canvas.getContext('2d');

    if (!ctx) return;

    // Set canvas size
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    // Draw video frame
    ctx.drawImage(video, 0, 0);

    // Draw overlay on top
    if (overlayCanvas.width > 0 && overlayCanvas.height > 0) {
      ctx.drawImage(overlayCanvas, 0, 0);
    }

    // Convert to data URL
    const photoData = canvas.toDataURL('image/jpeg', 0.9);
    setCapturedPhoto(photoData);
    
    toast.success('Photo captured with virtual try-on!');
  };

  // Switch camera (front/back)
  const switchCamera = async () => {
    stopCamera();
    setFacingMode(prev => prev === 'user' ? 'environment' : 'user');
    setTimeout(() => startCamera(), 100);
  };

  // Download captured photo
  const downloadPhoto = () => {
    if (capturedPhoto) {
      const link = document.createElement('a');
      link.download = `nyambika-virtual-tryon-${Date.now()}.jpg`;
      link.href = capturedPhoto;
      link.click();
      toast.success('Photo downloaded successfully!');
    }
  };

  // Start overlay rendering when streaming starts
  useEffect(() => {
    if (isStreaming && selectedClothing) {
      renderOverlay();
    }
  }, [isStreaming, selectedClothing, renderOverlay]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, []);

  const selectedClothingItem = clothingItems.find(item => item.id === selectedClothing);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2 flex items-center justify-center">
          <Shirt className="w-8 h-8 mr-3 text-indigo-600" />
          {t('virtualTryOn')} - Snapchat Style
        </h1>
        <p className="text-muted-foreground">
          Real-time virtual try-on with live camera feed - just like Snapchat filters!
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Panel - Controls */}
        <div className="space-y-6">
          {/* Clothing Selection */}
          <Card>
            <CardHeader>
              <CardTitle>Select Item to Try On</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select value={selectedClothing} onValueChange={setSelectedClothing}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose an item" />
                </SelectTrigger>
                <SelectContent>
                  {clothingItems.map((item) => (
                    <SelectItem key={item.id} value={item.id}>
                      {item.name} - {item.price}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {selectedClothingItem && (
                <div className="space-y-4">
                  <div className="flex items-center space-x-4 p-3 bg-muted rounded-lg">
                    <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-lg flex items-center justify-center text-white font-bold">
                      {selectedClothingItem.overlay.type === 'glasses' ? '👓' : '👗'}
                    </div>
                    <div>
                      <p className="font-medium">{selectedClothingItem.name}</p>
                      <p className="text-sm text-muted-foreground">{selectedClothingItem.category} • {selectedClothingItem.price}</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="size">Size</Label>
                      <Select value={selectedSize} onValueChange={setSelectedSize}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select size" />
                        </SelectTrigger>
                        <SelectContent>
                          {selectedClothingItem.sizes.map((size) => (
                            <SelectItem key={size} value={size}>
                              {size}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="color">Color</Label>
                      <Select value={selectedColor} onValueChange={setSelectedColor}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select color" />
                        </SelectTrigger>
                        <SelectContent>
                          {selectedClothingItem.colors.map((color) => (
                            <SelectItem key={color} value={color}>
                              {color}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Camera Controls */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Camera className="w-5 h-5 mr-2" />
                Camera Controls
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {!streamInitialized ? (
                <Button onClick={startCamera} className="w-full">
                  <Play className="w-4 h-4 mr-2" />
                  Start Camera
                </Button>
              ) : (
                <div className="space-y-2">
                  <div className="flex space-x-2">
                    <Button onClick={stopCamera} variant="outline" className="flex-1">
                      <Square className="w-4 h-4 mr-2" />
                      Stop
                    </Button>
                    <Button onClick={switchCamera} variant="outline" className="flex-1">
                      <RotateCcw className="w-4 h-4 mr-2" />
                      Flip
                    </Button>
                  </div>
                  
                  <Button 
                    onClick={capturePhoto} 
                    className="w-full"
                    disabled={!selectedClothing}
                  >
                    <Camera className="w-4 h-4 mr-2" />
                    Capture Photo
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Center Panel - Camera Feed */}
        <div className="space-y-6">
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Live Camera Feed
                {isStreaming && selectedClothing && (
                  <span className="text-sm text-green-600 dark:text-green-400 flex items-center">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                    AR Active
                  </span>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="relative aspect-[4/3] bg-black rounded-lg overflow-hidden">
                {streamInitialized ? (
                  <>
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover"
                    />
                    <canvas
                      ref={overlayCanvasRef}
                      className="absolute inset-0 w-full h-full pointer-events-none"
                      style={{ zIndex: 10 }}
                    />
                    {selectedClothing && (
                      <div className="absolute bottom-4 left-4 bg-black/50 text-white px-3 py-1 rounded-lg text-sm">
                        Trying on: {selectedClothingItem?.name}
                      </div>
                    )}
                  </>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                    <Camera className="w-16 h-16 mb-4" />
                    <p className="text-lg font-medium">Camera Not Started</p>
                    <p className="text-sm text-center">
                      Click "Start Camera" to begin virtual try-on
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Panel - Captured Photos */}
        <div className="space-y-6">
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Download className="w-5 h-5 mr-2" />
                Captured Photo
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {capturedPhoto ? (
                <div className="space-y-4">
                  <img 
                    src={capturedPhoto} 
                    alt="Captured try-on" 
                    className="w-full rounded-lg shadow-lg"
                  />
                  <div className="flex space-x-2">
                    <Button onClick={downloadPhoto} className="flex-1">
                      <Download className="w-4 h-4 mr-2" />
                      Download
                    </Button>
                    <Button variant="outline" onClick={() => setCapturedPhoto(null)}>
                      Clear
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-64 text-muted-foreground border-2 border-dashed border-border rounded-lg">
                  <Sparkles className="w-12 h-12 mb-4" />
                  <p className="font-medium">No Photos Yet</p>
                  <p className="text-sm text-center">
                    Capture a photo to save your virtual try-on
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Hidden canvas for photo capture */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Tips Section */}
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Snapchat-Style Tips</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Camera className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="font-medium mb-1">Good Lighting</h3>
              <p className="text-sm text-muted-foreground">Face the light source for better detection</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center mx-auto mb-2">
                <span className="text-green-600 dark:text-green-400 text-xl">🧍</span>
              </div>
              <h3 className="font-medium mb-1">Stay Centered</h3>
              <p className="text-sm text-muted-foreground">Keep your face/body centered in the frame</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Sparkles className="w-6 h-6 text-purple-600 dark:text-purple-400" />
              </div>
              <h3 className="font-medium mb-1">Real-Time AR</h3>
              <p className="text-sm text-muted-foreground">See clothing overlay in real-time like Snapchat</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Maximize2 className="w-6 h-6 text-orange-600 dark:text-orange-400" />
              </div>
              <h3 className="font-medium mb-1">Full Screen</h3>
              <p className="text-sm text-muted-foreground">Use full screen for better experience</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}